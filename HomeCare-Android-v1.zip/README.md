# HomeCare Android

**HomeCare — Your Home, Our Care.**

Android WebView app with an elegant branded HomeCare interface.

## Build
Open this project in Android Studio and run `:app`.

## Version 1
- Premium HomeCare branding
- Home dashboard
- Cleaning, garden and maintenance task categories
- Local task persistence
- Android notification permission/channel foundation
- Custom app icon

## Next
Native scheduled reminders, task history, family profiles, garden schedules, maintenance schedules, dark mode and cloud sync.
