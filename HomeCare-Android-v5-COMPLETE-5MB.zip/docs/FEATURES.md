# HomeCare 5.0 — Complete Household System

## Core
- Dashboard
- Daily/weekly/monthly/periodic tasks
- Household calendar
- Family roles and responsibilities
- Multiple household domains

## Home
- Cleaning and room routines
- Preventive maintenance
- Asset Passport
- Appliances and service history
- Bills and rent
- Document vault
- Safety checklists

## Shopping & Inventory
- Shopping lists
- Product capture
- Barcode-ready data model
- Receipt-ready data model
- Inventory lifecycle: purchased → stored → opened → used → expiring → reorder
- Consumption history

## Garden
- Plant passport
- Watering and observations
- Soil, sunlight and growth-stage fields
- Integrated pest management workflow

## Money
- Income
- Budget
- Expenses
- Savings
- Bill/payment history

## Family & Personal Care
- Family profiles
- Chores and responsibilities
- Medication reminder data model
- Health appointments and records
- Personal grooming and care reminders

## Evidence-aware guidance
Every recommendation is designed around:
WHAT / WHY / WHEN / HOW / SOURCE

The app must distinguish official guidance, manufacturer guidance, scientific evidence and practical tips.
Safety-sensitive actions require confirmation and appropriate professional/manufacturer guidance.

## Privacy
This foundation uses local app storage. Do not assume cloud backup or encryption unless explicitly implemented.
