plugins { id("com.android.application") }

android {
    namespace = "com.homecare.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.homecare.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 5
        versionName = "5.0.0"
    }
}

