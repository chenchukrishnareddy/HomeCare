const modules=[
['Cleaning','🧹','Daily, weekly and periodic cleaning routines.'],
['Maintenance','🔧','Preventive home and appliance maintenance.'],
['Shopping','🛒','Lists, product capture and purchase planning.'],
['Inventory','📦','Track stored, opened, used, expiring and reorder items.'],
['Money','₹','Income, budgets and household expenses.'],
['Bills','🧾','Bills, rent, due dates and payment history.'],
['Documents','📁','Invoices, warranties, agreements and home records.'],
['Garden','🌿','Plant passports, care, observations and IPM.'],
['Family','👨‍👩‍👧','People, responsibilities, chores and permissions.'],
['Health','♡','Appointments, records and reminder support.'],
['Vehicles','🚗','Service, insurance, documents and maintenance.'],
['Safety','🛡','LPG, electrical, fire, emergency and safety checks.'],
['Home Science','⚗','Evidence-informed household guidance and sources.'],
['Calendar','◷','One household calendar for tasks and reminders.'],
['Insights','◌','Patterns from the data you record.'],
['Sustainability','♻','Waste, water, energy and reuse tracking.']
];

function save(k,v){localStorage.setItem(k,JSON.stringify(v))}
function load(k,d){try{return JSON.parse(localStorage.getItem(k))??d}catch(e){return d}}

function home(){
 return `<div class="hero">
  <div class="eyebrow">HOMECARE 5.0 • COMPLETE HOUSEHOLD SYSTEM</div>
  <h1>A healthier home starts here.</h1>
  <p>Clean. Maintain. Organize. Track. Care for your home and the people in it — from one simple place.</p>
  <span class="version">VERSION 5.0.0 • FOUNDATION BUILD</span>
 </div>
 <div class="section">Today</div>
 <div class="grid">
  <div class="card"><div class="ico">✓</div><b>3 tasks</b><small>Keep today's routine moving.</small></div>
  <div class="card"><div class="ico">₹</div><b>2 bills</b><small>Review upcoming payments.</small></div>
  <div class="card"><div class="ico">🔧</div><b>1 maintenance</b><small>Preventive care due.</small></div>
  <div class="card"><div class="ico">🛒</div><b>Shopping</b><small>Check your active list.</small></div>
 </div>
 <div class="section">Household systems</div>
 <div class="grid">${modules.slice(0,12).map(m=>`<div class="card" onclick="module('${m[0]}')"><div class="ico">${m[1]}</div><b>${m[0]}</b><small>${m[2]}</small></div>`).join('')}</div>
 <div class="section">Home Science</div>
 <div class="card" onclick="module('Home Science')"><div class="ico">⚗</div><b>Evidence-informed guidance</b><small>WHAT • WHY • WHEN • HOW • SOURCE. Guidance is informational; manufacturer labels and qualified professionals remain important for safety-sensitive decisions.</small></div>
`}

function tasks(){
 let t=load('tasks',[['Sweep living areas','Daily'],['Clean kitchen surfaces','Daily'],['Bathroom deep clean','Weekly'],['Inspect garden plants','Weekly']]);
 return `<button class="back" onclick="show('home')">‹</button><h2>Tasks</h2>
 <div class="pill">Daily</div><div class="pill">Weekly</div><div class="pill">Monthly</div><div class="pill">Periodic</div>
 ${t.map((x,i)=>`<div class="task"><input type="checkbox" ${x[2]?'checked':''} onchange="toggleTask(${i})"><div><b>${x[0]}</b><small>${x[1]} • household routine</small></div></div>`).join('')}
 <button class="btn" onclick="addTask()">＋ Add task</button>`}

function modulePage(name){
 const data=modules.find(x=>x[0]===name);
 const info={
 'Cleaning':'Build room-by-room routines using frequency, usage, soil/load and manufacturer guidance.',
 'Maintenance':'Create asset service schedules, repair history and preventive checks.',
 'Shopping':'Create lists and use camera/receipt capture as inputs for review before saving.',
 'Inventory':'Track quantities, opened dates, expiry/best-before and user-defined reorder levels.',
 'Money':'Record income, budgets and household expenses. Start manually; add integrations only when implemented.',
 'Bills':'Store provider, amount, due date, recurrence, payment status and receipts.',
 'Documents':'Keep warranties, invoices, agreements, manuals and important household records.',
 'Garden':'Plant passport + observations + weather/season context + integrated pest management workflow.',
 'Family':'Profiles, roles, responsibilities and household activity with permissions.',
 'Health':'Medication reminders follow prescription/label directions; store appointments and health documents without diagnosis.',
 'Vehicles':'Track service, insurance, PUC/registration, tyres, battery, repairs and documents.',
 'Safety':'Use checklists for LPG, electrical, fire, emergency information and chemical storage.',
 'Home Science':'Show source type and evidence context. Suggested sources include WHO, CDC, EPA, FSSAI, FAO, ICAR and manufacturer documentation.',
 'Calendar':'Bring household tasks, bills, maintenance, garden and family dates into one view.',
 'Insights':'Summaries should be calculated from the household data you actually record.',
 'Sustainability':'Track waste, recycling, compost, water, energy and reuse actions.'
 };
 return `<button class="back" onclick="show('home')">‹</button>
 <div class="hero"><div class="eyebrow">HOMECARE 5.0</div><h1>${name}</h1><p>${info[name]||data?.[2]||''}</p></div>
 <div class="section">Core records</div>
 <div class="list"><b>＋ Add ${name} record</b><p>Use the action button to create a record. Your information is kept locally in this foundation build.</p><button class="btn" onclick="addRecord('${name}')">Add record</button></div>
 <div class="list"><b>Suggested workflow</b><p>Capture → Review → Save → Schedule → Remind → History → Insights.</p></div>
 ${name==='Home Science'?`<div class="list"><b>Source library</b><div class="source"><a href="https://www.who.int/">WHO</a> • <a href="https://www.cdc.gov/">CDC</a> • <a href="https://www.epa.gov/">EPA</a> • <a href="https://www.fssai.gov.in/">FSSAI</a> • <a href="https://www.fao.org/">FAO</a> • <a href="https://icar.gov.in/">ICAR</a></div></div>`:''}
 <div class="tag">Evidence-aware • Confirm before important actions</div>`;
}

function add(){return `<div class="hero"><div class="eyebrow">QUICK ADD</div><h1>What would you like to add?</h1><p>Choose a household input. Important actions should be reviewed before saving.</p></div><div class="grid">${['Task','Purchase','Expense','Bill','Document','Asset','Plant','Family member','Medicine reminder','Appointment'].map(x=>`<div class="card" onclick="addRecord('${x}')"><div class="ico">＋</div><b>${x}</b><small>Create a new record.</small></div>`).join('')}</div>`}

function more(){return `<h2>More</h2><div class="grid">${modules.map(m=>`<div class="card" onclick="module('${m[0]}')"><div class="ico">${m[1]}</div><b>${m[0]}</b><small>${m[2]}</small></div>`).join('')}</div>`}
function insights(){return `<h2>Insights</h2><div class="hero"><div class="eyebrow">DATA-BASED</div><h1>Your home, in one view.</h1><p>Insights will use recorded tasks, purchases, inventory, spending and maintenance history rather than invented scores.</p></div><div class="list"><b>Privacy-first foundation</b><p>Local browser storage is used in this build. Do not assume cloud backup or encryption is enabled unless a future build implements it.</p></div>`}
function profile(){return `<h2>HomeCare 5.0</h2><div class="list"><b>Version 5.0.0</b><p>Complete household system foundation.</p><span class="tag">Simple outside. Powerful inside.</span></div><div class="list"><b>Brand</b><p>Your Home, Our Care.</p></div>`}

function show(p){document.getElementById('content').innerHTML={home,tasks,add,more,insights,profile}[p]();window.scrollTo(0,0)}
function module(n){document.getElementById('content').innerHTML=modulePage(n);window.scrollTo(0,0)}
function addRecord(n){alert(n+' record screen is ready for the next data-entry layer.');}
function addTask(){let t=load('tasks',[]);t.push(['New household task','Custom']);save('tasks',t);show('tasks')}
function toggleTask(i){let t=load('tasks',[]);t[i][2]=!t[i][2];save('tasks',t)}
show('home')
