# HomeCare Android v3

**Your Home, Our Care.**

A clean Android WebView application for household cleaning, garden and maintenance reminders.

## Build

The project uses:
- Java 17
- Android Gradle Plugin 8.7.3
- Gradle 8.10.2
- Android SDK 35
- No Kotlin
- No AndroidX dependencies

The GitHub Actions workflow in `.github/workflows/build-apk.yml` builds a debug APK and uploads it as an artifact.
