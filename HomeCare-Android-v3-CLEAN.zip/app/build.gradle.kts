plugins {
    id("com.android.application")
}

android {
    namespace = "com.homecare.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.homecare.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
        }
    }
}
