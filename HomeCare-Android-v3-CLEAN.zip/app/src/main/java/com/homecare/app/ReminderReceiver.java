package com.homecare.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "homecare_reminders";

    @Override
    public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("title");
        if (title == null || title.isEmpty()) title = "HomeCare reminder";
        String repeat = intent.getStringExtra("repeat");
        String taskId = intent.getStringExtra("taskId");

        Intent open = new Intent(context, MainActivity.class);
        PendingIntent contentIntent = PendingIntent.getActivity(
                context, 9001, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder;
        if (android.os.Build.VERSION.SDK_INT >= 26)
            builder = new Notification.Builder(context, CHANNEL_ID);
        else
            builder = new Notification.Builder(context);

        builder.setSmallIcon(com.homecare.app.R.drawable.homecare_icon)
                .setContentTitle("HomeCare")
                .setContentText(title)
                .setAutoCancel(true)
                .setContentIntent(contentIntent);

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(taskId == null ? 1001 : taskId.hashCode(), builder.build());

        if ("daily".equals(repeat) || "weekly".equals(repeat) || "monthly".equals(repeat)) {
            Calendar next = Calendar.getInstance();
            if ("daily".equals(repeat)) next.add(Calendar.DAY_OF_YEAR, 1);
            if ("weekly".equals(repeat)) next.add(Calendar.WEEK_OF_YEAR, 1);
            if ("monthly".equals(repeat)) next.add(Calendar.MONTH, 1);

            AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            Intent again = new Intent(context, ReminderReceiver.class);
            again.putExtra("title", title);
            again.putExtra("repeat", repeat);
            again.putExtra("taskId", taskId);
            int request = taskId == null ? 1001 : Math.abs(taskId.hashCode() % 1000000);
            PendingIntent pi = PendingIntent.getBroadcast(
                    context, request, again,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            if (android.os.Build.VERSION.SDK_INT >= 23)
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
            else
                alarm.set(AlarmManager.RTC_WAKEUP, next.getTimeInMillis(), pi);
        }
    }
}
