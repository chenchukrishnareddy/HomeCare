# HomeCare release rules
