# HomeCare Android

HomeCare — **Your Home, Our Care.**

A lightweight Android app for household cleaning, maintenance, garden care, schedules and reminders.

## Build
This project intentionally uses **Java only** (no Kotlin), so Java/Kotlin JVM-target mismatch errors are avoided.

GitHub Actions builds a debug APK automatically.

## APK
After a successful GitHub Actions run:
Actions → Build HomeCare APK → run → Artifacts → HomeCare-debug-apk
