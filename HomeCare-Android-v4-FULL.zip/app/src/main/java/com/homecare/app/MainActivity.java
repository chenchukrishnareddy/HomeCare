package com.homecare.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.webkit.*;
import android.widget.Toast;

public class MainActivity extends Activity {
    WebView web;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new WebViewClient());
        web.loadUrl("file:///android_asset/index.html");
        setContentView(web);
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 10);
    }
    public class Bridge {
        @JavascriptInterface public void toast(String s){ Toast.makeText(MainActivity.this,s,Toast.LENGTH_SHORT).show(); }
        @JavascriptInterface public void scheduleReminder(String title, String text, long millis){
            Intent i = new Intent(MainActivity.this, ReminderReceiver.class);
            i.putExtra("title", title); i.putExtra("text", text);
            PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, (int)(millis%100000), i, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            ((AlarmManager)getSystemService(ALARM_SERVICE)).set(AlarmManager.RTC_WAKEUP, millis, pi);
        }
    }
}