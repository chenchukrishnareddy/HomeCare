package com.homecare.app;
import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    public void onReceive(Context c, Intent i){
        String channel="homecare_reminders";
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(channel,"HomeCare Reminders",NotificationManager.IMPORTANCE_DEFAULT));
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,channel):new Notification.Builder(c);
        b.setSmallIcon(com.homecare.app.R.drawable.homecare_icon).setContentTitle(i.getStringExtra("title")).setContentText(i.getStringExtra("text")).setAutoCancel(true);
        nm.notify((int)(System.currentTimeMillis()%100000),b.build());
    }
}